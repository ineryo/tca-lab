﻿# Entregável — Lista 02: Geometria Computacional

Este pacote reúne a entrega da **Lista 02 — Geometria Computacional** da
disciplina **Técnicas Computacionais Avançadas**.

## Conteúdo principal

- Relatório final interativo:  
  [assignments/02-geometry/resposta.html](assignments/02-geometry/resposta.html)

- Notebook completo da solução:  
  [assignments/02-geometry/solucao.ipynb](assignments/02-geometry/solucao.ipynb)

- Documentação detalhada do entregável:  
  [assignments/02-geometry/README.md](assignments/02-geometry/README.md)

- Enunciado original:  
  [assignments/02-geometry/lista_02-gc.pdf](assignments/02-geometry/lista_02-gc.pdf)

## Organização

O arquivo `resposta.html` é o documento principal de leitura e reúne as
explicações, resultados e visualizações interativas.

O notebook `solucao.ipynb` preserva o desenvolvimento completo da solução,
incluindo experimentos, validações e geração das figuras.

Os fontes C++ relevantes utilizados nas soluções também estão incluídos neste
pacote.

## Repositório

A implementação faz parte do projeto **TCA Lab**, mantido e atualizado em:

https://github.com/ineryo/tca-lab

Este ZIP representa uma versão autocontida da solução no momento da entrega.
O repositório Git pode conter atualizações posteriores, melhorias de
implementação, documentação, testes e novas funcionalidades.
