﻿# Entregável — Lista 01: Algoritmos de Ordenação

Apresentação final: [slides/lista.html](assignments/01-sorting/slides/lista.html).

A documentação completa, incluindo instruções e fontes incorporados, está em
[assignments/01-sorting/README.md](assignments/01-sorting/README.md).
